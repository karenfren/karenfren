import os 
import numpy as ka
import funciones as re
dep=ka.empty([10,4],type(int))
compradores=[]
ventasTotales=[]
precios=[{"depto":"Tipo A, 3.800 UF","tipo":"A","precio":3.800},
        {"depto":"ipo B, 3.000 UF ","tipo":"B","precio":3.000},
        {"depto":" Tipo C, 2.800 UF","tipo":"C","precio":2.800},
        {"depto":"ipo D, 3.500 UF","tipo":"D","precio":3.500}]
dep = re.llenarmatriz(dep)
op=0
while op!=5:
    print("********CASA FELIZ**********")
    print("1-. Comprar departamento")
    print("2-. Mostrar departamentos disponibles")
    print("3-. Ver listado de compradores")
    print("4-. Mostrar ganancias totales")
    print("5-.                  SALIR")
    op=re.valop()
    if op==1:
        re.mostrar(dep)
        re.valdep(dep,compradores,precios,ventasTotales)
        os.system("pause")
    if op==2:
        re.mostrar(dep) 
    if op==3:
        re.mostrarcompradores(compradores)
    if op==4:
        re.mostrarventas(ventasTotales)