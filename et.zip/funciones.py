from opcode import hasjabs
import os
import numpy as ka
import pandas
def llenarmatriz(dep):
    n=1
    for j in range(10):
        for k in range (4):
            dep[j,k]
            n+=1
    return dep
def MatrizDeptos():
    arreglo = [{""}*4]*10
    return arreglo
def valop():
    nn=0
    while True:
        try:
            nn=int(input("Elija una opcion del menu: "))
            if nn>=1 and nn<=5:
                break
            else:
                print("Elija una de las 5 opciones")
        except ValueError:
                    print("Ingrese un numero del 1 al 5")
    return nn
def mostrar(dep):
    os.system("cls")
    dep=pandas.DataFrame(dep,columns=["A","B","C","D"],index=[10, 9, 8, 7,6,5,4,3,2,1])
    print(dep)
def valdep(dep,compradores,precios,ventasTotales):
    hab=0
    compra=False
    while compra==False:
        try:
            print(f"Si departamento A en el piso 9,Ingrese A9")
            hab=str(input("Ingrese Departamento: "))
            if (len(hab)==2):
                print("Validando disponibiidad...")
                validarDisponibilidad(hab,dep,compradores,precios,ventasTotales)
                compra=True
            else:
                break
        except ValueError:
            print("iIngrese habitacion valida")
    return hab

def validarDisponibilidad(depto,dep,compradores,precios,ventasTotales):
    pisoIngresado=depto[1:2]
    deptoIngresado=depto[0:1]
    piso = 10-int(pisoIngresado)
    if(deptoIngresado=="A"):
        if(dep[piso][0]==""):
            print(f"Ingrese rut de comprador")
            rut=str(input("RUT: "))
            if rut != "":
                compradores.append(rut)
                dep[piso][0]="X"
                print(dep[piso][0])
                print("El Departamento ha sido comprado con éxito")
                venta = precios[0]
                ventasTotales.append(venta)
            else:
                print("El Departamento no está disponible")
                if(deptoIngresado=="B"):
                    if(dep[piso][1]==""):
                        print(f"Ingrese rut de comprador")
                        rut=str(input("RUT: "))
                        if rut != "":
                            compradores.append(rut)
                            dep[piso][1]="X"
                            print(dep[piso][1])
                            print("El Departamento ha sido comprado con éxito")
                            venta = precios[1]
                            ventasTotales.append(venta)